custom_params = {}
custom_params['model_dir'] = 'nn_models/shape_only/model_data/'
custom_params['out_dir'] = 'output/shape_only/'
custom_params['feat_mask'] = [1.0, 1.0, 0.0, 0.0, 0.0]
