custom_params = {}
custom_params['model_dir'] = 'nn_models/all_feat_1l/model_data/'
custom_params['out_dir'] = 'output/all_feat_1l/'
custom_params['feat_mask'] = [1.0, 1.0, 1.0, 1.0, 1.0]
custom_params['n_conv_layers'] = 1
