custom_params = {}
custom_params['model_dir'] = 'nn_models/hphob_only/model_data/'
custom_params['out_dir'] = 'output/hphob_only/'
custom_params['feat_mask'] = [0.0, 0.0, 0.0, 0.0, 1.0]
custom_params['n_conv_layers'] = 3
